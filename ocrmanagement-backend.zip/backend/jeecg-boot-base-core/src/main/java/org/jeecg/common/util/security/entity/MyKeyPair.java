package org.jeecg.common.util.security.entity;

import lombok.Data;

/**
 * @Description: MyKeyPair
 * @author: jeecg-boot
 */
@Data
public class MyKeyPair {
    private String priKey;
    private String pubKey;
}
