package org.jeecg.common.util.security.entity;

import lombok.Data;

/**
 * @Description: SecuritySignReq
 * @author: jeecg-boot
 */
@Data
public class SecuritySignReq {
    private String data;
    private String prikey;
}
