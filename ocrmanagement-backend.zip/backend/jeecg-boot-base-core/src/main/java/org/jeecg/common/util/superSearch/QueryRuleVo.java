//package org.jeecg.common.util.superSearch;
//
//import lombok.Data;
//
///**
// * @Description: QueryRuleVo
// * @author: jeecg-boot
// */
//@Data
//public class QueryRuleVo {
//
//	private String field;
//	private String rule;
//	private String val;
//}
