package org.jeecg.modules.system.controller;


import org.jeecg.modules.system.service.RolePermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * RolePermissionController - 角色权限控制器
 */
@RestController
@RequestMapping("/api/roles")
public class RolePermissionController {

    @Autowired
    private RolePermissionService rolePermissionService;

    @PostMapping
    public String addRole(@RequestBody RolePermissionDTO roleDTO) {
        rolePermissionService.addRole(roleDTO);
        return "Role added successfully";
    }

    @DeleteMapping("/{roleId}")
    public String deleteRole(@PathVariable Long roleId) {
        rolePermissionService.deleteRole(roleId);
        return "Role deleted successfully";
    }

    @GetMapping("/{roleId}/permissions")
    public RolePermissionDTO getRolePermissions(@PathVariable Long roleId) {
        return rolePermissionService.getRolePermissions(roleId);
    }

    @PutMapping("/{roleId}/permissions")
    public String updateRolePermissions(@PathVariable Long roleId, @RequestBody List<Long> permissionIds) {
        rolePermissionService.updateRolePermissions(roleId, permissionIds);
        return "Permissions updated successfully";
    }
}
