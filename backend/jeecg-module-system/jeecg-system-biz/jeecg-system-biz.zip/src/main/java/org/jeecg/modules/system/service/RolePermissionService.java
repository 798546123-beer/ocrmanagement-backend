//package org.jeecg.modules.system.service;
//
//
//import java.util.List;
//
///**
// * RolePermissionService - 角色权限服务接口
// */
//public interface RolePermissionService {
//    void addRole(RolePermissionDTO roleDTO);
//    void deleteRole(Long roleId);
//    RolePermissionDTO getRolePermissions(Long roleId);
//    void updateRolePermissions(Long roleId, List<Long> permissionIds);
//}
