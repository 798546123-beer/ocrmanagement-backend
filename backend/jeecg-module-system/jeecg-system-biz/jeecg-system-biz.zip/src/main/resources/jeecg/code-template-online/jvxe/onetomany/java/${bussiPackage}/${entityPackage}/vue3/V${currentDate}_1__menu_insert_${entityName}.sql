<#include "/common/sql/menu_insert.ftl">
